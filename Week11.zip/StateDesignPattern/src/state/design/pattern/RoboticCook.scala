package state.design.pattern

class RoboticCook(private val robot: Robot) extends RoboticState {

  override def walk(): Unit = {
    println("Walking...")
    robot.setRoboticState(robot.getRoboticOn)
  }

  override def cook(): Unit = {
    println("Cooking...")
  }

  override def off(): Unit = {
    println("Cannot switched off while cooking...")
  }

}