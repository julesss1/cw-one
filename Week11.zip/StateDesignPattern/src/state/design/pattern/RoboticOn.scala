package state.design.pattern

class RoboticOn(private val robot: Robot) extends RoboticState {

  override def walk(): Unit = {
    println("Walking...")
  }

  override def cook(): Unit = {
    println("Cooking...")
    robot.setRoboticState(robot.getRoboticCook)
  }

  override def off(): Unit = {
    robot.setState(robot.getRoboticOff)
    println("Robot is switched off")
  }

}