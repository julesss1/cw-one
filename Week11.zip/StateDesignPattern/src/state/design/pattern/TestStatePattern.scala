package state.design.pattern

object TestStatePattern {

  def main(args: Array[String]): Unit = {
    val robot: Robot = new Robot()
    robot.walk()
    robot.cook()
    robot.walk()
    robot.off()
    robot.walk()
    robot.off()
    robot.cook()
  }

}
