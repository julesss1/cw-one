package state.design.pattern

import scala.beans.BeanProperty

class Robot extends RoboticState {

  @BeanProperty
  var roboticOn: RoboticState = new RoboticOn(this)

  @BeanProperty
  var roboticCook: RoboticState = new RoboticCook(this)

  @BeanProperty
  var roboticOff: RoboticState = new RoboticOff(this)

  @BeanProperty
  var state: RoboticState = roboticOn

  def setRoboticState(state: RoboticState): Unit = {
    this.state = state
  }

  override def walk(): Unit = {
    state.walk()
  }

  override def cook(): Unit = {
    state.cook()
  }

  override def off(): Unit = {
    state.off()
  }

}
