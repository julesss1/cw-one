package visitor.design.pattern

trait Element {

  def accept(visitor: Visitor): Unit

}