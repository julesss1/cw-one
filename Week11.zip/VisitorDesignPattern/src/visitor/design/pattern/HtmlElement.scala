package visitor.design.pattern

import scala.beans.{BeanProperty, BooleanBeanProperty}

//remove if not needed
import scala.collection.JavaConversions._

class HtmlElement(@BeanProperty var tagName: String) extends HtmlTag {

  @BeanProperty
  var startTag: String = ""

  @BeanProperty
  var endTag: String = ""

  private var tagBody: String = ""

  override def setTagBody(tagBody: String): Unit = {
    this.tagBody = tagBody
  }

  override def generateHtml(): Unit = {
    println(startTag + "" + tagBody + "" + endTag)
  }

  override def accept(visitor: Visitor): Unit = {
    visitor.visit(this)
  }

}