package visitor.design.pattern
import java.util.ArrayList

import java.util.List

import scala.beans.{BeanProperty, BooleanBeanProperty}

//remove if not needed
import scala.collection.JavaConversions._

class HtmlParentElement(@BeanProperty var tagName: String) extends HtmlTag {

  @BeanProperty
  var startTag: String = ""

  @BeanProperty
  var endTag: String = ""

  private var childrenTag: List[HtmlTag] = new ArrayList()

  override def addChildTag(htmlTag: HtmlTag): Unit = {
    childrenTag.add(htmlTag)
  }

  override def removeChildTag(htmlTag: HtmlTag): Unit = {
    childrenTag.remove(htmlTag)
  }

  override def getChildren(): List[HtmlTag] = childrenTag

  override def generateHtml(): Unit = {
    println(startTag)
    for (tag <- childrenTag) {
      tag.generateHtml()
    }
    println(endTag)
  }

  override def accept(visitor: Visitor): Unit = {
    visitor.visit(this)
  }

}
