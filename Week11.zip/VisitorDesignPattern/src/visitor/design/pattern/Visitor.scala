package visitor.design.pattern

trait Visitor {

  def visit(element: HtmlElement): Unit

  def visit(parentElement: HtmlParentElement): Unit

}