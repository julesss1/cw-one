package template.design

object TestTemplatePattern {

  def main(args: Array[String]): Unit = {
    println("For MYSQL....")
    var template: ConnectionTemplate = new MySqLCSVCon()
    template.run()
    println("For Oracle...")
    template = new OracleTxtCon()
    template.run()
  }

}