package observer.pattern

//remove if not needed
import scala.collection.JavaConversions._

class SMSUsers(private val subject: Subject, private var userInfo: String)
    extends Observer {

  private var desc: String = _

  if (subject == null) {
    throw new IllegalArgumentException("No Publisher found.")
  }

  override def update(desc: String): Unit = {
    this.desc = desc
    display()
  }

  private def display(): Unit = {
    println("[" + userInfo + "]: " + desc)
  }

  override def subscribe(): Unit = {
    println(
      "Subscribing " + userInfo + " to " + subject.subjectDetails() +
        " ...")
    this.subject.subscribeObserver(this)
    println("Subscribed successfully.")
  }

  override def unSubscribe(): Unit = {
    println(
      "Unsubscribing " + userInfo + " to " + subject.subjectDetails() +
        " ...")
    this.subject.unSubscribeObserver(this)
    println("Unsubscribed successfully.")
  }

}