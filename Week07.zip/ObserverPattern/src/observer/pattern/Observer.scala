package observer.pattern

trait Observer {
  def update(desc: String)

  def subscribe()

  def unSubscribe()
}
