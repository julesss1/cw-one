package observer.pattern

trait Commentary {
  def setDesc(desc: String)
}
