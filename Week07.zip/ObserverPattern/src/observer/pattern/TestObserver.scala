package observer.pattern

import java.util.ArrayList;

object TestObserver {
  def main(args: Array[String]): Unit = {
    val subject: Subject = new CommentaryObject(new ArrayList[Observer](),
                                                "Soccer Match [2015MAY18]")
    val observer: Observer = new SMSUsers(subject, "David Beckham [England]")
    observer.subscribe()
    println()
    val observer2: Observer = new SMSUsers(subject, "Cristiano Ronaldo [Brazil]")
    observer2.subscribe()
    val cObject: Commentary = subject.asInstanceOf[Commentary]
    cObject.setDesc("Welcome to live Soccer match")
    cObject.setDesc("Current score 0-0")
    println()
    observer2.unSubscribe()
    println()
    cObject.setDesc("It's a goal!!")
    cObject.setDesc("Current score 1-0")
    println()
    val observer3: Observer = new SMSUsers(subject, "Neymar [barcelona]")
    observer3.subscribe()
    println()
    cObject.setDesc("It's another goal!!")
    cObject.setDesc("Half-time score 2-0")
  }

}