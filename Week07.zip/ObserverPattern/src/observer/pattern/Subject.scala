package observer.pattern

trait Subject {
  def subscribeObserver(observer: Observer): Unit

  def unSubscribeObserver(observer: Observer): Unit

  def notifyObservers(): Unit

  def subjectDetails(): String
}
