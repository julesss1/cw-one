package observer.pattern

import java.util.List
import scala.collection.JavaConversions._

class CommentaryObject(private val observers: List[Observer],
                       var subjectDetails: String)
    extends Subject
    with Commentary {

  private var desc: String = _

  override def subscribeObserver(observer: Observer): Unit = {
    observers.add(observer)
  }

  override def unSubscribeObserver(observer: Observer): Unit = {
    val index: Int = observers.indexOf(observer)
    observers.remove(index)
  }

  override def notifyObservers(): Unit = {
    println()
    for (observer <- observers) {
      observer.update(desc)
    }
  }

  override def setDesc(desc: String): Unit = {
    this.desc = desc
    notifyObservers()
  }

}