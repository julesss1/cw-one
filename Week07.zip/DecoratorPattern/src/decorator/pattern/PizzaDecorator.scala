package decorator.pattern

import scala.collection.JavaConversions._

abstract class PizzaDecorator extends Pizza {

  override def getDesc(): String = "Toppings"

}