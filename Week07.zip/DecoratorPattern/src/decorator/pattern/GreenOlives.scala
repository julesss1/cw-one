package decorator.pattern

class GreenOlives(private val pizza: Pizza) extends PizzaDecorator {

  override def getDesc(): String = pizza.getDesc + ", Green Olives (5.47)"

  override def getPrice(): Double = pizza.getPrice + 5.47

}
