package decorator.pattern

trait Pizza {

  def getDesc(): String

  def getPrice(): Double

}