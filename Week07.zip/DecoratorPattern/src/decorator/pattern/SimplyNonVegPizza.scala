package decorator.pattern

class SimplyNonVegPizza extends Pizza {

  override def getDesc(): String = "SimplyNonVegPizza (350)"

  override def getPrice(): Double = 350

}
