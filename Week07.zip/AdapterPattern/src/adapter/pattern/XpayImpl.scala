package adapter.pattern

import scala.beans.BeanProperty

class XpayImpl extends Xpay {

  @BeanProperty
  var creditCardNo: String = _

  @BeanProperty
  var customerName: String = _

  @BeanProperty
  var cardExpMonth: String = _

  @BeanProperty
  var cardExpYear: String = _

  @BeanProperty
  var cardCVVNo: java.lang.Short = _

  @BeanProperty
  var amount: java.lang.Double = _

}