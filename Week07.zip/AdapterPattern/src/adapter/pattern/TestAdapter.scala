package adapter.pattern

object TestAdapter {

  def main(args: Array[String]): Unit = {
// Object for Xpay
    val xpay: Xpay = new XpayImpl()
    xpay.setCreditCardNo("12345678910")
    xpay.setCustomerName("Julian Heissl")
    xpay.setCardExpMonth("12")
    xpay.setCardExpYear("20")
    xpay.setCardCVVNo(198.toShort)
    xpay.setAmount(3065.23)
    val payD: PayD = new XpayToPayDAdapter(xpay)
    testPayD(payD)
  }

  private def testPayD(payD: PayD): Unit = {
    println(payD.getCardOwnerName)
    println(payD.getCustCardNo)
    println(payD.getCardExpMonthDate)
    println(payD.getCVVNo)
    println(payD.getTotalAmount)
  }

}