package adapter.pattern

trait PayD {

  def getCustCardNo(): String

  def getCardOwnerName(): String

  def getCardExpMonthDate(): String

  def getCVVNo(): java.lang.Integer

  def getTotalAmount(): java.lang.Double

  def setCustCardNo(custCardNo: String): Unit

  def setCardOwnerName(cardOwnerName: String): Unit

  def setCardExpMonthDate(cardExpMonthDate: String): Unit

  def setCVVNo(cVVNo: java.lang.Integer): Unit

  def setTotalAmount(totalAmount: java.lang.Double): Unit

}