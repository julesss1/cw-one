package adapter.pattern

trait Xpay {

  def getCreditCardNo(): String

  def getCustomerName(): String

  def getCardExpMonth(): String

  def getCardExpYear(): String

  def getCardCVVNo(): java.lang.Short

  def getAmount(): java.lang.Double

  def setCreditCardNo(creditCardNo: String): Unit

  def setCustomerName(customerName: String): Unit

  def setCardExpMonth(cardExpMonth: String): Unit

  def setCardExpYear(cardExpYear: String): Unit

  def setCardCVVNo(cardCVVNo: java.lang.Short): Unit

  def setAmount(amount: java.lang.Double): Unit

}