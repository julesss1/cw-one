package factory.pattern

object Test {

  def main(arg: Array[String]): Unit = {
    val c: Creator = new ConcreteCreator()
    val p: Product = c.factoryMethod()
    println("Created", p)
  }

}