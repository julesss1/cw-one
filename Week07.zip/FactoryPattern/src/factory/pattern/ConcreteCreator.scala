package factory.pattern

class ConcreteCreator extends Creator {

  def factoryMethod(): Product = new ConcreteProduct()
  
}