package factory.pattern

abstract class Creator {

  def factoryMethod(): Product {
    
  }

}