package factory.pattern

class ConcreteProduct extends Product {
    override def createProduct { println("product created") }
}