package factory.pattern

trait Product {
  def createProduct
}