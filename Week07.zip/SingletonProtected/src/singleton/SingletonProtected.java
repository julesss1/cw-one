package singleton;

import java.io.Serializable;

public class SingletonProtected implements Serializable,Cloneable{

private static final long serialVersionUID = 1L;

private static SingletonProtected singleton=null;
private SingletonProtected(){
	System.out.println("Singleton Constructor Running...");
	}

public static SingletonProtected getInstance(){
    if(singleton==null){
        singleton=new SingletonProtected();
    }
    return singleton;   
	}

@Override
public Object clone() throws CloneNotSupportedException{
    return super.clone();
	}
}