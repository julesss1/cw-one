package singleton;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/***
 * 
 * Ways to break Singleton
 */
public class Test {

public static void main(String[] args) throws Exception {
    SingletonProtected orginalSingletonObject = SingletonProtected.getInstance();
    
    Class clazz = SingletonProtected.class;

    Constructor cons = clazz.getDeclaredConstructor();
    cons.setAccessible(true);

    SingletonProtected s2 = (SingletonProtected) cons.newInstance();
   }
}